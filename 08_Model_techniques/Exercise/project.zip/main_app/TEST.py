list_a = ['1', '2', '3', '4', '5']

for a in list_a:
    if a.isdigit:
        print(type(a))


tel = '+359882210059z'

print(tel[0:4])
print(tel[4:].isdigit)